//
//  ViewController.swift
//  AMAN-Application
//
//  Created by Ghaida on 06/02/2020.
//  Copyright © 2020 GHAIDa. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

